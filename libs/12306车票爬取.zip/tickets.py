# Created by Lin at 2023/1/18 23:16:12
# IDE name：PyCharm
# File name：tickets.py

from requests import get
from re import findall
from json import loads
from colorama import Fore, Style

# 请求头参数
headers1 = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 '
                  'Safari/537.36 Edg/109.0.1518.55'
}
headers2 = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 '
                  'Safari/537.36 Edg/109.0.1518.55',
    'Cookie': '_uab_collina=167405524534316712525509; JSESSIONID=A3E54B150E54966175EE03A49E3BD33D; guidesStatus=off; '
              'highContrastMode=defaltMode; cursorStatus=off; BIGipServerpassport=904397066.50215.0000; '
              'RAIL_EXPIRATION=1674352052362; RAIL_DEVICEID=pr7x44bUYKJG4bPEemQ35PjdGj7ot3C6BuUflkwuGm1XqGC6oB1P33k_1_t'
              'jrI9gmVQPhe0yqkkV62NKtAtss0XJSLur1URGSSvyI5QWflnBz0m2d1XszWeYhKx5CAWob8IWiU4TIpd_6oSFg3jx4nm8SUDoPLkc; '
              'route=9036359bb8a8a461c164a04f8f50b252; _jc_save_wfdc_flag=dc; BIGipServerportal=3084124426.17695.0000; '
              'BIGipServerindex=1071186186.43286.0000; BIGipServerotn=384303370.24610.0000; fo=5wtghtoqq09epso645qwaek-'
              'Pl3Epzl4ddtaNoooFC8gxuik4YG9oaM8BM5KIIYSEiPxHweUNljt2PvuOrbfbt36TW0KEO2ct_jZm3iNhDTBIikXcpWE6FyfcjVJhx7h'
              'QPKGxcff3dZH3AkY4DiWaaRlgHYr9GqRGcxLk51nPXYTkEgj8rB3btx7U8w; _jc_save_fromStation=%u676D%u5DDE%2CBJP; '
              '_jc_save_toStation=%u4E0A%u6D77%2CSHH; _jc_save_fromDate=2023-01-30; _jc_save_toDate=2023-01-19'
}


# 如果传入的 string 为空，则返回标识 '-'
def none_str(string):
    if string == '':
        return '-'
    elif string is None:
        return '-'
    else:
        return string


# 将历时中，如 '05:51' 的形式，改为 '05小时51分'
def pass_time(string: str):
    if len(string) == 5:
        string = string.replace(':', '小时') + '分'
        return string
    else:
        return None


def main(_from, _to, _date, _purpose_codes='ADULT'):
    return_result = []
    # 获取目的地、始发地的地区（或车站）代码
    station_name_js_url = 'https://kyfw.12306.cn/otn/resources/js/framework/station_name.js'
    response = get(station_name_js_url, headers=headers1)
    stations = dict(findall(r'([\u4e00-\u9fa5]+)\|([A-Z]+)', response.text))
    # print(stations)

    # 根据字典查找始发地代码
    _from = stations[_from]
    _to = stations[_to]
    # print(_from, _to, _date, _purpose_codes)

    # 获取车次信息
    queryz_url = f'https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={_date}&leftTicketDTO.' \
                 f'from_station={_from}&leftTicketDTO.to_station={_to}&purpose_codes={_purpose_codes}'
    response = get(queryz_url, headers=headers2)
    queryz = loads(response.text)

    # print(queryz_url)
    # print(response)
    # print(queryz)
    # 解析车次信息
    map_dict = queryz['data']['map']
    trains_result = queryz['data']['result']

    # print(map_dict)
    for i in trains_result:
        # print('————————————————————————————————————————————————————————————————————————————————————————————————————')
        d = i.split('|')
        # print(d)
        '''https://kyfw.12306.cn/otn/leftTicket/init?linktypeid=dc&fs={},{}&ts={},{}&date={}&flag=N,N,Y
           缺少 软座 、 其他 的车票信息


           车次   出发站  到达站 出发时间 到达时间  历时   商务座/特等座  一等座  二等座/二等包座 高级软卧 软卧一等卧 动卧
           d[3]  d[6]   d[7]  d[8]    d[9]   d[10]  d[32]        d[31]   d[30]       d[21]   d[23]    d[33]    
           
           硬卧二等卧 软座   硬座     无座     其它
           d[28]     x    d[29]   d[26]     x
        '''
        # print(d[3], map_dict[d[6]], map_dict[d[7]], d[8], d[9], d[10], noneString(d[32]), noneString(d[31]),
        #       noneString(d[30]), noneString(d[21]), noneString(d[23]), noneString(d[33]), noneString(d[28]),
        #       noneString(d[29]), noneString(d[26]))

        # print(d[3], map_dict[d[6]], d[8], d[10], noneString(d[32]), noneString(d[31]),
        #       noneString(d[30]), noneString(d[21]), noneString(d[23]), noneString(d[33]), noneString(d[28]),
        #       noneString(d[29]), noneString(d[26]))
        # print(map_dict[d[7]],d[9])
        return_result.append([[d[3], Fore.RED + map_dict[d[6]] + Style.RESET_ALL, Fore.RED + d[8] + Style.RESET_ALL,
                               pass_time(d[10]), none_str(d[32]), none_str(d[31]), none_str(d[30]), none_str(d[21]),
                               none_str(d[23]), none_str(d[33]), none_str(d[28]), none_str(d[29]), none_str(d[26])],
                              ['', Fore.GREEN + map_dict[d[7]] + Style.RESET_ALL, Fore.GREEN + d[9] + Style.RESET_ALL,
                               '', '', '', '', '', '', '', '', '', '']])
    return return_result


if __name__ == '__main__':
    FROM = '杭州'
    TO = '福州'
    # DATE = '2023-01-30'
    DATE = '2023-06-01'
    # 成人：ADULT      学生：0X00
    purpose_codes = 'ADULT'
    print(main(FROM, TO, DATE, purpose_codes))
