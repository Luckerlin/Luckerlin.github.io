# Created by Lin at 2023/1/19 12:55:26
# IDE name：PyCharm
# File name：prettyprint.py

import tickets
from prettytable import PrettyTable


def print_table(_from, _to, _date, _purpose_codes='ADULT'):
    x = PrettyTable()
    x.field_names = ['车次', '站点', '时间', '历时', '商务座/特等座', '一等座', '二等座/二等包座', '高级软卧',
                     '软卧一等卧',
                     '动卧', '硬卧二等卧', '硬座', '无座']
    lists = tickets.main(_from, _to, _date, _purpose_codes='ADULT')
    # print(lists)
    for i in lists:
        for s in i:
            x.add_row(s)
    print(x)


if __name__ == '__main__':
    from_ = '北京'
    to = '杭州'
    date = '2023-06-01'
    purpose_codes = 'ADULT'
    print_table(from_, to, date, purpose_codes)
